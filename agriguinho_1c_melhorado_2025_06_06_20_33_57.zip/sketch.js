let jardineiro;
let plantas = [];
let temperatura = 10;
let totalArvores = 0;

let imgMachado; // Renomeado para evitar conflito e clareza
let machadoAtual = null; // Variável para controlar o machado ativo
let tempoProximoMachado = 0;
const INTERVALO_MACHADO = 5000; // Tempo em milissegundos para o machado aparecer (5 segundos)

function preload() {
  imgMachado = loadImage("machado.png"); // Carrega a imagem do machado
}

function setup() {
  createCanvas(600, 400);
  jardineiro = new Jardineiro(width / 2, height - 50);

  // Crie algumas árvores iniciais no cenário
  for (let i = 0; i < 5; i++) {
    plantas.push(new Arvore(random(50, width - 50), random(100, height - 150)));
    totalArvores++; // Conta as árvores iniciais como plantadas
  }
}

function draw() {
  // A cor do fundo muda conforme a quantidade de árvores plantadas
  let corFundo = lerpColor(color(217, 112, 26), color(219, 239, 208), map(totalArvores, 0, 10, 0, 1));
  background(corFundo);

  mostrarInformacao();

  // A temperatura é inversamente proporcional ao número de árvores
  // Menos árvores = maior temperatura (map de 0 a 20 árvores para temperatura de 30 a 0)
  temperatura = map(totalArvores, 0, 10, 30, 0); 
  // Garante que a temperatura não seja menor que 0 ou maior que 30 (ajuste conforme a dificuldade desejada)
  temperatura = constrain(temperatura, 0, 30); 

  jardineiro.mostrar();
  jardineiro.atualizar();

  // Desenha todas as árvores
  for (let arvore of plantas) {
    arvore.mostrar();
  }

  // Lógica para o machado aparecer
  if (machadoAtual === null && millis() > tempoProximoMachado) {
    // Define um novo tempo para o próximo machado aparecer, com uma variação aleatória
    tempoProximoMachado = millis() + INTERVALO_MACHADO + random(-2000, 2000); 

    // Encontre uma árvore plantada aleatoriamente para o machado cortar
    let arvoresPlantadas = plantas.filter(arvore => arvore.plantada);
    if (arvoresPlantadas.length > 0) {
      let arvoreAlvo = random(arvoresPlantadas);
      machadoAtual = new Machado(arvoreAlvo.x, arvoreAlvo.y, arvoreAlvo);
    }
  }

  // Se houver um machado ativo, ele será exibido e realizará sua ação
  if (machadoAtual !== null) {
    machadoAtual.exibir();
  }
}

// ---
// Funções Auxiliares
// ---

function mostrarInformacao() {
  textSize(20);
  fill(0); // Cor do texto
  text("Temperatura: " + temperatura.toFixed(2) + "°C", 10, 30);
  text("Árvores plantadas: " + totalArvores, 10, 50);
  text("Mova o jardineiro com as setas. Pressione 'Espaço' para plantar.", 10, 70);
}

// ---
// Classes do Jogo
// ---

// Classe que cria o jardineiro
class Jardineiro {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.emoji = '👨‍🌾';
    this.velocidade = 3;
  }

  atualizar() {
    // Movimento do jardineiro
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.velocidade;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.velocidade;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.velocidade;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.velocidade;
    }

    // Limita o jardineiro dentro da tela
    this.x = constrain(this.x, 20, width - 20);
    this.y = constrain(this.y, 20, height - 20);
  }

  mostrar() {
    textSize(32);
    text(this.emoji, this.x - 16, this.y - 16); // Ajusta a posição para centralizar o emoji
  }
}

// Lógica de plantio e replantio
function keyPressed() {
  if (key === ' ' || key === 'p') {
    let replantou = false;
    // Tenta replantar uma árvore cortada próxima
    for (let i = 0; i < plantas.length; i++) {
      let arvore = plantas[i];
      if (!arvore.plantada) { // Se a árvore estiver cortada
        let d = dist(jardineiro.x, jardineiro.y, arvore.x, arvore.y);
        if (d < 50) { // Se o jardineiro estiver perto da árvore cortada (ajuste a distância conforme necessário)
          arvore.plantada = true; // Replantar
          totalArvores++; // Incrementa o total de árvores
          temperatura -= 3; // Diminui a temperatura ao replantar
          if (temperatura < 0) temperatura = 0;
          console.log("Árvore replantada!");
          replantou = true;
          break; // Sai do loop após replantar uma árvore
        }
      }
    }

    // Se não replantou nenhuma árvore cortada por perto, permite plantar uma nova
    if (!replantou) {
      // Cria uma nova árvore na posição do jardineiro
      let arvore = new Arvore(jardineiro.x, jardineiro.y);
      plantas.push(arvore);
      totalArvores++;
      temperatura -= 3;
      if (temperatura < 0) temperatura = 0;
      console.log("Nova árvore plantada!");
    }
  }
}

class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.emoji = '🌳'; // Emoji padrão para árvore plantada
    this.plantada = true; // Começa como plantada
  }

  mostrar() {
    textSize(32);
    // Mude o emoji dependendo do estado da árvore
    if (this.plantada) {
      this.emoji = '🌳'; // Árvore plantada
    } else {
      this.emoji = '🪵'; // Toco da árvore quando cortada
    }
    text(this.emoji, this.x - 16, this.y - 16); // Ajusta a posição para centralizar o emoji
  }
}

class Machado {
  constructor(x, y, arvoreAlvo) {
    this.x = x;
    this.y = y;
    this.arvoreAlvo = arvoreAlvo; // A árvore que este machado vai cortar
    this.visivel = true;
    this.tempoAcao = millis() + 500; // Machado fica visível por 0.5 segundos antes de "cortar"
  }

  exibir() {
    if (this.visivel) {
      image(imgMachado, this.x -25, this.y -25, 170, 170); // Ajusta o tamanho e a posição da imagem do machado

      // Lógica para cortar a árvore
      if (millis() > this.tempoAcao) {
        if (this.arvoreAlvo && this.arvoreAlvo.plantada) {
          this.arvoreAlvo.plantada = false; // Define a árvore como cortada
          totalArvores--; // Decrementa o total de árvores
          temperatura += 5; // Aumenta a temperatura ao cortar
          if (temperatura > 30) temperatura = 30; // Limita a temperatura máxima
          console.log("Árvore cortada!");
        }
        this.visivel = false; // Machado desaparece após cortar
        machadoAtual = null; // Limpa o machado ativo para que outro possa aparecer
      }
    }
  }
}

