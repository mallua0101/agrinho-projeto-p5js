let jardineiro;
let plantas = [];
let temperatura = 10;
let totalArvores = 0;
let pontuacao = 0; // Variável para a pontuação
let jogoAtivo = true; // Controla se o jogo está rodando

let imgMachado;
let machadoAtual = null;
let tempoProximoMachado = 0;
let intervaloMachadoBase = 5000; // Tempo base para o machado aparecer (5 segundos)
let velocidadeMachado = 1; // Controla a frequência do machado (maior valor = mais rápido)

// Variáveis para os sons
let somCorte;
let somPlantio;
let somAmbiente; // Opcional: som de fundo para o jogo
let somGameOver; // Som para game over
let somVitoria; // Som para vitória

function preload() {
  imgMachado = loadImage("machado.png");
  // Carregue seus arquivos de som aqui. Certifique-se de que os nomes correspondem!
  somCorte = loadSound("som_corte.mp3");
  somPlantio = loadSound("som_plantio.mp3");
  somGameOver = loadSound("som_game_over.mp3"); // Ex: um som triste, de falha
  somVitoria = loadSound("som_vitoria.mp3"); // Ex: um som de celebração, vitoria
  // somAmbiente = loadSound("som_ambiente.mp3"); // Descomente e coloque seu som ambiente se quiser
}

function setup() {
  createCanvas(600, 400);
  // Inicializa o jogo ao começar
  reiniciarJogo();

  // Opcional: Tocar som ambiente em loop
  // if (somAmbiente.isLoaded()) {
  //   somAmbiente.loop();
  //   somAmbiente.setVolume(0.3); // Ajusta o volume do som ambiente
  // }
}

function draw() {
  if (jogoAtivo) {
    // Cor do fundo muda conforme a quantidade de árvores plantadas
    let corFundo = lerpColor(color(217, 112, 26), color(219, 239, 208), map(totalArvores, 0, 15, 0, 1));
    background(corFundo);

    mostrarInformacao();

    // A temperatura é inversamente proporcional ao número de árvores
    // Menos árvores = maior temperatura. O 'map' faz a transição entre 0-15 árvores e 30-0 graus.
    temperatura = map(totalArvores, 0, 15, 30, 0);
    temperatura = constrain(temperatura, 0, 30); // Garante que a temperatura fique entre 0 e 30

    jardineiro.mostrar();
    jardineiro.atualizar();

    // Desenha todas as árvores
    for (let arvore of plantas) {
      arvore.mostrar();
    }

    // Lógica para o machado aparecer
    // A frequência do machado aumenta com o tempo para dificultar o jogo
    let intervaloAtualMachado = intervaloMachadoBase / velocidadeMachado;
    if (machadoAtual === null && millis() > tempoProximoMachado) {
      // Define um novo tempo para o próximo machado aparecer, com uma variação aleatória
      tempoProximoMachado = millis() + intervaloAtualMachado + random(-1000, 1000);

      // Encontra uma árvore plantada aleatoriamente para o machado cortar
      let arvoresPlantadas = plantas.filter(arvore => arvore.plantada);
      if (arvoresPlantadas.length > 0) {
        let arvoreAlvo = random(arvoresPlantadas);
        machadoAtual = new Machado(arvoreAlvo.x, arvoreAlvo.y, arvoreAlvo);
      }
    }

    // Se houver um machado ativo, ele será exibido e realizará sua ação
    if (machadoAtual !== null) {
      machadoAtual.exibir();
    }

    // Aumenta a velocidade do machado a cada 15 segundos
    // (60 frames por segundo * 15 segundos = 900 frames)
    if (frameCount % (60 * 15) === 0) {
        velocidadeMachado += 0.1; // Aumenta a velocidade
        velocidadeMachado = constrain(velocidadeMachado, 1, 3); // Limita a velocidade máxima
        console.log("Dificuldade aumentada! Velocidade do machado: " + velocidadeMachado.toFixed(1));
    }


    // --- Condições de Fim de Jogo / Vitória ---
    if (temperatura >= 28) { // Quase no limite, avisa o jogador com texto vermelho
      fill(255, 0, 0); // Vermelho vibrante
      textSize(24);
      textAlign(CENTER); // Centraliza o texto
      text("A TEMPERATURA ESTÁ MUITO ALTA!", width / 2, height / 2 + 50);
      textAlign(LEFT); // Volta ao alinhamento padrão
    }

    if (temperatura >= 30) {
      fimDeJogo(false); // Game Over por alta temperatura
    } else if (totalArvores >= 15) { // Exemplo: vitória ao plantar 15 árvores
      fimDeJogo(true); // Vitória
    }

  } else {
    // Desenha a tela de Game Over ou Vitória quando o jogo não está ativo
    mostrarTelaFimDeJogo();
  }
}

// ---
// Funções Auxiliares
// ---

function mostrarInformacao() {
  textSize(20);
  fill(0); // Cor do texto principal
  text("Temperatura: " + temperatura.toFixed(2) + "°C", 10, 30);
  text("Árvores: " + totalArvores + "/15", 10, 50); // Mostra progresso para vitória (15 árvores)
  
  textSize(14); // Instruções menores
  text("Mova com SETAS. Espaço para PLANTAR/REPLANTAR.", 10, 95);

  // Exibe a pontuação no canto superior direito com destaque
  textSize(28);
  fill(0, 150, 0); // Verde vibrante
  text("Pontos: " + pontuacao, width - 150, 30);
}

function fimDeJogo(vitoria) {
  if (jogoAtivo) { // Garante que a função só execute uma vez ao mudar o estado
    jogoAtivo = false;
    // Para todos os sons que talvez estejam tocando em loop
    // if (somAmbiente.isPlaying()) {
    //   somAmbiente.stop();
    // }
    if (somCorte.isPlaying()) somCorte.stop(); // Garante que o som de corte pare
    if (somPlantio.isPlaying()) somPlantio.stop(); // Garante que o som de plantio pare

    if (vitoria) {
      if (somVitoria.isLoaded()) somVitoria.play();
    } else {
      if (somGameOver.isLoaded()) somGameOver.play();
    }
  }
}

function mostrarTelaFimDeJogo() {
  background(0); // Fundo preto para a tela final
  fill(255); // Texto branco
  textAlign(CENTER); // Alinha o texto ao centro

  if (totalArvores >= 15) { // Condição de vitória
    textSize(48);
    text("VITÓRIA!", width / 2, height / 2 - 30);
    textSize(24);
    text("Você salvou o planeta!", width / 2, height / 2 + 10);
  } else { // Condição de Game Over
    textSize(48);
    text("GAME OVER", width / 2, height / 2 - 30);
    textSize(24);
    text("A temperatura subiu demais...", width / 2, height / 2 + 10);
  }

  textSize(18);
  text("Pontuação Final: " + pontuacao, width / 2, height / 2 + 60);
  text("Pressione 'R' para jogar novamente", width / 2, height / 2 + 100);
  textAlign(LEFT); // Volta para o alinhamento padrão para o próximo frame
}

// Nova função para reiniciar o jogo
function reiniciarJogo() {
  plantas = []; // Limpa todas as árvores
  temperatura = 10;
  totalArvores = 0;
  pontuacao = 0;
  jogoAtivo = true;
  machadoAtual = null; // Garante que não haja machado ativo no início
  tempoProximoMachado = 0;
  velocidadeMachado = 1; // Reseta a velocidade do machado

  // Recria as árvores iniciais no cenário
  for (let i = 0; i < 5; i++) {
    plantas.push(new Arvore(random(50, width - 50), random(100, height - 150)));
    totalArvores++;
  }

  // Reinicia o som ambiente, se estiver sendo usado e não estiver tocando
  // if (somAmbiente.isLoaded() && !somAmbiente.isPlaying()) {
  //   somAmbiente.loop();
  //   somAmbiente.setVolume(0.3);
  // }
}

// ---
// Classes do Jogo
// ---

// Classe que cria o jardineiro
class Jardineiro {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.emoji = '👨‍🌾';
    this.velocidade = 3;
  }

  atualizar() {
    // Movimento do jardineiro com as setas do teclado
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.velocidade;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.velocidade;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.velocidade;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.velocidade;
    }

    // Limita o jardineiro dentro da área visível da tela
    this.x = constrain(this.x, 20, width - 20);
    this.y = constrain(this.y, 20, height - 20);
  }

  mostrar() {
    textSize(32);
    // Ajusta a posição para centralizar o emoji do jardineiro
    text(this.emoji, this.x - 16, this.y - 16);
  }
}

// Lógica de plantio e replantio das árvores
function keyPressed() {
  if (jogoAtivo) { // Só permite ações se o jogo estiver ativo
    if (key === ' ' || key === 'p') {
      let replantou = false;
      // Tenta replantar uma árvore cortada próxima ao jardineiro
      for (let i = 0; i < plantas.length; i++) {
        let arvore = plantas[i];
        // Verifica se a árvore está cortada e se o jardineiro está perto (distância menor que 50)
        if (!arvore.plantada && dist(jardineiro.x, jardineiro.y, arvore.x, arvore.y) < 50) {
          arvore.plantada = true; // Replantar a árvore
          totalArvores++; // Incrementa o contador de árvores
          temperatura -= 3; // Diminui a temperatura (bom para o planeta!)
          temperatura = constrain(temperatura, 0, 30); // Garante que a temperatura não seja negativa
          pontuacao += 100; // Ganha pontos por replantar
          if (somPlantio.isLoaded()) { // Toca o som de plantio
            somPlantio.play();
          }
          replantou = true; // Indica que uma árvore foi replantada
          break; // Sai do loop após replantar uma árvore
        }
      }

      // Se não replantou nenhuma árvore cortada por perto, permite plantar uma nova
      if (!replantou) {
        // Limita o número máximo de árvores para evitar que a tela fique superlotada
        if (plantas.length < 25) {
          let arvore = new Arvore(jardineiro.x, jardineiro.y); // Cria uma nova árvore na posição do jardineiro
          plantas.push(arvore); // Adiciona a nova árvore à lista
          totalArvores++; // Incrementa o contador de árvores
          temperatura -= 3; // Diminui a temperatura
          temperatura = constrain(temperatura, 0, 30); // Garante que a temperatura não seja negativa
          pontuacao += 50; // Ganha pontos por plantar uma nova árvore
          if (somPlantio.isLoaded()) { // Toca o som de plantio
            somPlantio.play();
          }
        } else {
            // Mensagem de log para indicar que o limite de árvores foi atingido
            console.log("Limite de árvores atingido! Replante as árvores cortadas para liberar espaço.");
        }
      }
    }
  } else { // Se o jogo não estiver ativo (Game Over ou Vitória)
    if (key === 'r' || key === 'R') { // Verifica se a tecla 'R' foi pressionada para reiniciar
      reiniciarJogo();
    }
  }
}

// Classe que representa uma Árvore
class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.emoji = '🌳'; // Emoji padrão para árvore plantada
    this.plantada = true; // A árvore começa como plantada
  }

  mostrar() {
    textSize(32);
    // Muda o emoji dependendo do estado da árvore (plantada ou cortada)
    if (this.plantada) {
      this.emoji = '🌳'; // Árvore plantada
    } else {
      this.emoji = '🪵'; // Toco da árvore (cortada)
    }
    // Ajusta a posição para centralizar o emoji da árvore
    text(this.emoji, this.x - 16, this.y - 16);
  }
}

// Classe que representa o Machado
class Machado {
  constructor(x, y, arvoreAlvo) {
    this.x = x;
    this.y = y;
    this.arvoreAlvo = arvoreAlvo; // A referência à árvore que este machado vai cortar
    this.visivel = true; // O machado é visível inicialmente
    this.tempoAcao = millis() + 500; // O machado fica visível por 0.5 segundos antes de "cortar"
  }

  exibir() {
    if (this.visivel) {
      // Exibe a imagem do machado, ajustando o tamanho e a posição
      image(imgMachado, this.x - 25, this.y - 25, 50, 50);

      // Lógica para cortar a árvore após um tempo
      if (millis() > this.tempoAcao) {
        // Verifica se a árvore alvo ainda existe e está plantada
        if (this.arvoreAlvo && this.arvoreAlvo.plantada) {
          this.arvoreAlvo.plantada = false; // Define a árvore como cortada
          totalArvores--; // Decrementa o total de árvores
          temperatura += 5; // Aumenta a temperatura (efeito negativo)
          temperatura = constrain(temperatura, 0, 30); // Garante que a temperatura não ultrapasse o máximo
          pontuacao -= 75; // Perde pontos por árvore cortada
          if (somCorte.isLoaded()) { // Toca o som de corte
            somCorte.play();
          }
        }
        this.visivel = false; // O machado desaparece após a ação
        machadoAtual = null; // Libera o machado ativo para que outro possa aparecer
      }
    }
  }
}
